import requests
import json
import sys, os
from airtable import AirtableClientFactory, AirtableSorter, SortDirection

## airtableのデータを取得

airtabledata = []
airtabledata = getAirTable()

if airtabledata == '':
    sys.exit()

## 書き込むデータを作成する
write_airtable_all_data = []
write_airtable_all_data = createWriteData(airtabledata)

## airtableにデータを書き込み
for writedata in write_airtable_all_data:
	recordid = writedata[0]
	slackid = writedata[1]
	kotid = writedata[2]

    updateAirTable(recordid, slackid, kotid)

## 関数
## 書き込むデータを作成する
def createWriteData():
    _write_airtable_all_data = []
    for data in airtabledata:
        write_airtable_1_data = []

        employeenumber = data['employeenumber']
        email = data['email']

        recordid = data['id']
        slackid = getSlackId(email)
        employeeid = getKotEmployKey(employeenumber)

        write_airtable_1_data.append(id)
        write_airtable_1_data.append(slackid)
        write_airtable_1_data.append(employeeid)

        _write_airtable_all_data.append(write_airtable_1_data)

    return _write_airtable_all_data

## airtableのデータを読み出す
def getAirTable():
    airtableBaseKey = os.environ['AIRTABLE_BASE_KEY']
    airtableApiKey = os.environ['AIRTABLE_API_KEY']

    atf = AirtableClientFactory(base_id=airtableBaseKey, api_key=airtableApiKey)
    at = atf.create('Employee_directory')

    atRecord = at.get_all_by('slack_id', '', view='All_employees').get()
    addAllList = []
    for rec in atRecord.records:
    	#print(rec)
    	add1List = []
        recordid = rec.get('id')
    	email = rec.get('fields').get('Email address')
    	id = rec.get('fields').get('ID')
    	#print(id)
        add1List.append(recordid)
    	add1List.append(id)
    	add1List.append(email)
    	addAllList.append(add1List)
    	#print(addAllList)
    return addAllList

## slackidを取得する
def getSlackId(email):
    url = "https://slack.com/api/users.lookupByEmail"
    token = "xoxp-2338654258-590677159606-667111078791-0248d7f6da119038852568335bc18daf"
    #email = "hasegawa@kanmu.co.jp"

    payload = {
        'content-type': "application/json",
        'token': token,
        'email': email
        }

    response = requests.request("GET", url, params=payload)
    userinfo = json.loads(response.text)

    print(userinfo["user"]["id"])

    return userinfo["user"]["id"]

## employeekey を取得する
def getKotEmployKey(code):
    employKey = '8774a2663a1247c7e321746607cf1b6203f54af6a20f0d7ca0f5303f887f13ba'
    url = "https://api.kingtime.jp/v1.0/employees"
    # カンムの従業員番号
    #code = '0017'

    headers = {
        'Authorization': "Bearer fd2be97cd0644c0ba54ef027e1b9e2e5",
        'content-type': "application/json",
        }

    userData = {
        "additionalFields": 'currentDateEmployee',
    }
    #payload = JSON.stringify(userData);

    response = requests.request("GET", url, headers=headers)

    #print(response.text)
    a = json.loads(response.text)
    #print(a)
    for item in a:
        if(item["code"] == code):
            #print(item["lastName"] + item["firstName"])
            print(item["key"])

            return item["key"]

# airtableに書き込む
def updateAirTable(recordid, slackid, kotid):
    airtableBaseKey = os.environ['AIRTABLE_BASE_KEY']
    airtableApiKey = os.environ['AIRTABLE_API_KEY']

    atf = AirtableClientFactory(base_id=airtableBaseKey, api_key=airtableApiKey)
    at = atf.create('Employee_directory')

    fields = {
   	    'slack_id': slackid,
   	    'kot_id': kotid
    }

    record = at.update(recordid, fields).get()
    #print(record)